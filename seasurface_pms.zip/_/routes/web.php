<?php

Route::get('/reports', 'ReportController@index');
Route::get('/reports/{reports}', 'ReportController@show');
Route::get('/create', 'ReportController@create');
Route::post('/report', 'ReportController@store');

Route::get('/login', 'LoginController@create')->name('login');
Route::post('/login', 'LoginController@store');
Route::get('/logout', 'LoginController@destroy');

Route::get('/register', 'RegisterController@create');
Route::post('/register', 'RegisterController@store');

Route::get('/map', 'MapController@index');

Route::get('/info', 'InfoController@index');
Route::get('/info/fauna', 'InfoController@indexFauna');
Route::get('/info/flora', 'InfoController@indexFlora');
Route::get('/info/fauna/{faunas}', 'InfoController@showFauna');
Route::get('/info/flora/{floras}', 'InfoController@showFlora');


Route::get('/', function () {

	$mapa = 'Map';
	$reports = 'Reports';
	$info = 'Info';

    return view('welcome', compact('mapa','reports','info'));
});

Route::get('/test', function () {

	$lat = '2';
	$long = '4';

    return view('reports.test', compact('lat', 'long'));
});
<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
Route::get('/reports', 'ReportController@index');
Route::get('/reports/{reports}', 'ReportController@show');
Route::get('/create', 'ReportController@create');
//Route::post('/report', 'ReportController@store');
Route::post('/report', ['as' => 'fauna', 'flora', 'latitude', 'longitude', 'description', 'picture' => 'ReportController@store']);
Route::get('/token', 'ReportController@showToken');

//Route::get('/login', 'LoginController@create')->name('login');
//Route::post('/login', 'LoginController@store');
Route::post('/login', ['as' => 'email', 'password' => 'LoginController@store']);
Route::get('/logout', 'LoginController@destroy');

//Route::get('/register', 'RegisterController@create');
//Route::post('/register', 'RegisterController@store');
Route::post('/register', ['as' => 'name', 'surname', 'username', 'password', 'email' => 'RegisterController@store']);

Route::get('/map', 'MapController@index');

Route::get('/info', 'InfoController@index');
Route::get('/info/fauna', 'InfoController@indexFauna');
Route::get('/info/flora', 'InfoController@indexFlora');
Route::get('/info/fauna/{faunas}', 'InfoController@showFauna');
Route::get('/info/flora/{floras}', 'InfoController@showFlora');


Route::get('/', function () {

	$mapa = 'Map';
	$reports = 'Reports';
	$info = 'Info';

    return view('welcome', compact('mapa','reports','info'));
});
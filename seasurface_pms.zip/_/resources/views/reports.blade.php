<!doctype html>

<html>
  <head>
   
    <title></title>   
   
  </head>
   
    <body>
     
     <div class="flex-center position-ref full-height">

          @auth
          
            <a href="/create"> Create report </a>
              
          @else
          
            <a href="/login"> Login to create a report</a>

          @endauth 

      </div>
       
	@foreach ($reports as $report)
      <li>
      <a href="/reports/{{ $report->id }}">
        <li> Report number: {{ $report->id }} </li>
      </a> 
      	<li>{{ $report->description }}</li>
      	<li>{{ $report->user->name }} "{{ $report->user->username }}" {{ $report->user->surname }} </li>
        
        <?php
        if (!isset($report->fauna->name)) {
          ?> <li>{{ $report->flora->name }}</li> <?php 
        } 
        else {
          ?> <li>{{ $report->fauna->name }}</li> <?php
        } 
        ?>
      	<li>{{ $report->picture }}</li>
     
     </li>
     <hr>
    @endforeach
        
    </body>

</html>


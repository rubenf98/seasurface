<!doctype html>

<html>
  <head>
   
    <title></title>   
   
  </head>
   
    <body>
      	<h1>{{ $reports->description }} </h1>
      	<h1>{{ $reports->user->name }} "{{ $reports->user->username }}" {{ $reports->user->surname }} </h1>
      	<?php
        if (!isset($reports->fauna->name)) {
          ?> <h1>{{ $reports->flora->name }}</h1> <?php 
        } 
        else {
          ?> <h1>{{ $reports->fauna->name }}</h1> <?php
        } 
        ?>
      	<h1>{{ $reports->latitude }}</h1>
      	<h1>{{ $reports->longitude }}</h1>
      	<h1>{{ $reports->picture }}</h1>
        <h1>{{ $reports->created_at }}</h1>
    </body>

</html>
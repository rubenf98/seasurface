<!doctype html>

<html>
  <head>
   
    <title></title>   
   
  </head>
   
    <body>
     
    	<div style="width: 1300px; height: 600px;">
			{!! Mapper::render() !!}
		</div>
        
    </body>

</html>
<!doctype html>

<html>
  <head>
   
    <title></title>   
   
  </head>
   
    <body>
     
      <form method="POST" action="/register">

      			<div class="form-group">
			    	<label for="name" class="col-sm-2 control-label">Name</label>
			      	<input type="text" class="form-control" id="name" name="name" required>
			  	</div>

			  	<div class="form-group">
			    	<label for="surname" class="col-sm-2 control-label">Surname</label>
			      	<input type="text" class="form-control" id="surname" name="surname" required>
			  	</div>

			  	<div class="form-group">
			    	<label for="username" class="col-sm-2 control-label">Username</label>
			      	<input type="text" class="form-control" id="username" name="username" required>
			  	</div>


			    <div class="form-group">
			    	<label for="password" class="col-sm-2 control-label">Password</label>
			      	<input type="password" class="form-control" id="password" name="password" required>
			  	</div>

			  	<div class="form-group">
			    	<label for="email" class="col-sm-2 control-label">Email Adress</label>
			      	<input type="email" class="form-control" id="email" name="email" required>
			  	</div>

			  	<h1> </h1>
			  	<h1> </h1>
			  	<button type="submit" class="btn btn-primary">Register</button>
		
				@if (count($errors))
					<div class="form-group">
						<div class="alert alert-danger"
							<u1>
								@foreach ($errors->all() as $error)
									<li>{{ $error }}</li>
								@endforeach
							</u1>
						</div>
					</div>
				@endif

	</form>
        
    </body>

</html>
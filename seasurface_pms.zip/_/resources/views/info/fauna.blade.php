<!doctype html>

<html>
  <head>
   
    <title></title>   
   
  </head>
   
    <body>
     
         
    @foreach ($faunas as $fauna)
      <li>
      <a href="/info/fauna/{{ $fauna->id }}">
        <li> Animal: {{ $fauna->name }} </li>
      </a> 
        <li>{{ $fauna->description }}</li>
        <li>{{ $fauna->habitat }}</li>
        <li>{{ $fauna->food }}</li>
        
        <?php
        if (!isset($fauna->picture)) {
          ?> <li>{{ $fauna->picture }}</li> <?php 
        } ?>
        
        <?php
        if (!isset($fauna->lifespan)) {
          ?> <li>{{ $fauna->lifespan }}</li> <?php 
        }?>
        <hr>
    @endforeach
        
    </body>

</html>


<!doctype html>

<html>
  <head>
   
    <title></title>   
   
  </head>
   
    <body>
     
         
	@foreach ($floras as $flora)
      <li>
      <a href="/info/flora/{{ $flora->id }}">
        <li> Flora: {{ $flora->name }} </li>
      </a> 
        <li>{{ $flora->description }}</li>
        <li>{{ $flora->habitat }}</li>
        
        <?php
        if (!isset($flora->picture)) {
          ?> <li>{{ $flora->picture }}</li> <?php 
        } ?>
     <hr>
    @endforeach
        
    </body>

</html>


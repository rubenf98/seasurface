<!doctype html>

<html>
  <head>
   
    <title></title>   
   
  </head>
   
    <body>
        <h1>{{ $floras->name }} </h1>
        <h1>{{ $floras->description }}</h1>
        <h1>{{ $floras->habitat }}</h1>
        
        <?php
        if (!isset($floras->picture)) {
          ?> <h1>{{ $floras->picture }}</h1> <?php 
        } ?>
        
    </body>

</html>
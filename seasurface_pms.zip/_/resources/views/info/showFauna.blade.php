<!doctype html>

<html>
  <head>
   
    <title></title>   
   
  </head>
   
    <body>
      	<h1>{{ $faunas->name }} </h1>
      	<h1>{{ $faunas->description }}</h1>
      	<h1>{{ $faunas->habitat }}</h1>
        <h1>{{ $faunas->food }}</h1>
        
        <?php
        if (!isset($faunas->picture)) {
          ?> <h1>{{ $faunas->picture }}</h1> <?php 
        } ?>
        
        <?php
        if (!isset($faunas->lifespan)) {
          ?> <h1>{{ $faunas->lifespan }}</h1> <?php 
        }?>
    </body>

</html>
<!doctype html>

<html>
  <head>
   
    <title></title>   
   
  </head>
   
    <body>
     
      <h1> 
        <li> <a href="/info/fauna"> fauna </a> </li>
        <li> <a href="/info/flora"> flora </a> </li>
      </h1>
        
    </body>

</html>
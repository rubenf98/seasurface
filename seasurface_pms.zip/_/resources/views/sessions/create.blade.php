<!doctype html>

<html>
  <head>
   
    <title></title>   
   
  </head>
   
    <body>
     
      <form method="POST" action="/login">
      		


			  	<div class="form-group">
			    	<label for="email" class="col-sm-2 control-label">Email Adress</label>
			      	<input type="email" class="form-control" id="email" name="email" autocomplete="off" required>
			  	</div>

			  	<div class="form-group">
			    	<label for="password" class="col-sm-2 control-label">Password</label>
			      	<input type="password" class="form-control" id="password" name="password" autocomplete="off" required>
			  	</div>

			  	<h1> </h1>
			  	<h1> </h1>
			  	<button type="submit" class="btn btn-primary">Sign IN</button>
		
				

	</form>
        
    </body>

</html>
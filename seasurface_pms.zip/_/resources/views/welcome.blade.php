<!doctype html>

<html>
  <head>
   
    <title></title>   
   
  </head>
   
    <body>

      <div class="flex-center position-ref full-height">

          @auth
          
            <a href="/#"> Hi {{ Auth::user()->username }} </a>
            <a href="/logout"> Logout </a>
              
          @else
          
            <a href="/login"> Login </a>
            <a href="/register"> Register </a>  

          @endauth 

      </div>
            
      <hr>

      <h1> 
        <li> <a href="/map"> {{ $mapa }} </a> </li>
        <li> <a href="/reports"> {{ $reports }} </a> </li>
        <li> <a href="/info"> {{ $info }} </a> </li>
      </h1>


    </body>

</html>

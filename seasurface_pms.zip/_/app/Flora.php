<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Flora extends Model
{
    public function report()
    {
		 return $this->hasMany(Report::class);
    }

    public static function getId($name)
    {

    	return static::where('name',$name)->value('id');
    }

    public function scopeAll($query)
    {
    	return $query->all()->get();
    } 
}

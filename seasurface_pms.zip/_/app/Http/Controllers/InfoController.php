<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Flora;
use App\Fauna;

class InfoController extends Controller
{
    public function index()
    {
    	return view('info');
    }

    public function indexFlora()
    {
    	$floras = Flora::All();
    	//return view('info.flora', compact('floras'));
        return response()->json($floras);
    }

    public function indexFauna()
    {
    	$faunas = Fauna::All();
    	//return view('info.fauna', compact('faunas'));
        return response()->json($faunas);
    }

    public function showFauna(Fauna $faunas)
    {
    //return view('info.showFauna', compact('faunas'));
    return response()->json($faunas);
    }	

    public function showFlora(Flora $floras)
    {
    //return view('info.showFlora', compact('floras'));
    return response()->json($floras);
    }	
}

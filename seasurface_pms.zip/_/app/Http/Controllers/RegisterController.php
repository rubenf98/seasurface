<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use App\User;

class RegisterController extends Controller
{


    public function create()
	    {

	    return view('registration.create');

	    }

	public function store()
	{
		
		$input_request = new Request([
		'name' => Input::get('name'),
	  	'surname' => Input::get('surname'),
	  	'username' => Input::get('username'),
	  	'password' => Input::get('password'),
	  	'email' => Input::get('email')
		]);

		$this->validate($input_request, [
	  	'name' => 'required',
	  	'surname' => 'required', 
	  	'username' => 'required|min:3',
	  	'password' => 'required|min:3',
	  	'email' => 'required|email'
	  	]);

		$input=([
	  	'name' => Input::get('name'),
	  	'surname' => Input::get('surname'),
	  	'username' => Input::get('username'),
	  	'password' => bcrypt(Input::get('password')),
	  	'email' => Input::get('email')
	  	]);
	  	
		

	  	$user = User::create($input);

	  	

	  	// create the user
	  	//$user = User::create(request(['name', 'surname', 'username', 'password', 'email', ]));

	  	// sign him
	  	auth()->login($user);

	  	//return to homepage
	  	return response()->json($user);

		/*

	  	
	  	//Validate the form
	  	$this->validate(request(), [
	  	'name' => 'required',
	  	'surname' => 'required', 
	  	'username' => 'required|min:3',
	  	'password' => 'required|min:3',
	  	'email' => 'required|email'
	  	
	  	]);

	  	$user = User::create([
	  	'name' => request('name'),
	  	'surname' => request('surname'),
	  	'username' => request('username'),
	  	'password' => bcrypt(request('password')),
	  	'email' => request('email'),
	  	]);

	  	

	  	// create the user
	  	//$user = User::create(request(['name', 'surname', 'username', 'password', 'email', ]));

	  	// sign him
	  	auth()->login($user);

	  	//return to homepage
	  	return response()->json($user);
		*/
	  	
	  	
	}

	public function destroy()
	    {

	    

	    }
}

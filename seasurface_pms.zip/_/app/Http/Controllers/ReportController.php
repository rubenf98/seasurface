<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use App\Report;
use App\Fauna;
use App\Flora;


class ReportController extends Controller
{

    public function index()
	    {

	    	$reports = Report::CurrentReport();

	    	return response()->json($reports);
	    	
	    }

    public function show(Report $reports)
	    {

		    $report = Report::SpecificReport($reports->id);
		    
		    return response()->json($report);

	    }	

	public function create()
	    {
	   		
	   		return view('reports.create');
	   		
		}

	public function store()
	{
		$fauna_name = Input::get('fauna');
	  	$fauna_id = Fauna::GetID($fauna_name);

	  	$flora_name = Input::get('flora');
	  	$flora_id = Flora::GetID($flora_name);

		$input_request = new Request([
		'fauna' => $fauna_id,
		'flora' => $flora_id,
	  	'latitude' => Input::get('latitude'),
	  	'longitude' => Input::get('longitude'),
	  	'description' => Input::get('description')
		]);

		$this->validate($input_request, [
	  	'fauna' => 'required_without:flora',
	  	'latitude' => 'required',
	  	'longitude' => 'required',
	  	'description' => 'min:5|max:150'
	  	]);

		
	  	$input=([
	  	'user_id' => auth()->id(),
	  	'latitude' => Input::get('latitude'),
	  	'longitude' => Input::get('longitude'),
	  	'description' => Input::get('description'),
	  	'picture' => Input::get('picture')
	  	]);


	  	if(empty($fauna_id)){
	  		$inputfinal = Report::create(array_merge($input, ['flora_id' => $flora_id]));
	  	} 
	  	else {
	  		$inputfinal = Report::create(array_merge($input, ['fauna_id' => $fauna_id]));
	  	}

	  	return response()->json($inputfinal);

		/*$this->validate(request(), [
	  	'fauna' => 'required_without:flora',
	  	'latitude' => 'required',
	  	'longitude' => 'required',
	  	'description' => 'min:5|max:150'
	  	]);

		$fauna_name = request('fauna');
	  	$fauna_id = Fauna::GetID($fauna_name);

	  	$flora_name = request('flora');
	  	$flora_id = Flora::GetID($flora_name);

	  	$input=([
	  	'user_id' => auth()->id(),
	  	'latitude' => request('latitude'),
	  	'longitude' => request('longitude'),
	  	'description' => request('description'),
	  	'picture' => request('picture')
	  	]);


	  	if(empty($fauna_id)){
	  		$inputfinal = Report::create(array_merge($input, ['flora_id' => $flora_id]));
	  	} 
	  	else {
	  		$inputfinal = Report::create(array_merge($input, ['fauna_id' => $fauna_id]));
	  	}

	  	//return response()->json($inputfinal);
	
	  	//auth()->user()->publish(new Report(request(['user_id', 'latitude', 'longitude', 'description', 'picture']) + 'info_id' => $specie_id));


	  	//return redirect('/');*/
	}

}

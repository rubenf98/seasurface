<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
Use Mapper;

class MapController extends Controller
{
    public function index()
	{
	    Mapper::map(32.6500694, -16.8473492);
	    Mapper::marker(32.6000694, -16.8473492);
	    Mapper::marker(32.5500694, -16.8473492);


	    return view('mapa');
	}
}

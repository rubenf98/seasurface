<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\User;

class LoginController extends Controller
{

	

    public function create()
	{

	    return view('sessions.create');
	    //return response()->json();


	}

	public function destroy()
	{

	    auth()->logout();

	    return redirect('/');

	}

	public function store()
	{
		
		$input_request = ([
		'email' => Input::get('email'),
	  	'password' => Input::get('password')
		]);

	    if(!auth()->attempt($input_request))
	    {
	    	return response()->json("erro");
	    }
	    
	    return response()->json(User::getUser(Input::get('email')));
	    /*
	    $data = request()->all()

	   	if(!auth()->attempt($data))
	    {
	    	return response()->json($data);
	    }*/

	    //return redirect('/');
	    

	}
}

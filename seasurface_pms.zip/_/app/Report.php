<?php

namespace App;
use Carbon\Carbon;

class Report extends Model
{

    protected $guarded = [];

    public function scopeCurrentReport($query)
    {
    	return $query->where('created_at', '>=', Carbon::now()->subMonth())->latest()->with('Fauna')->with('Flora')->with('User')->get();
    }

    public static function SpecificReport($id)
    {
        return static::where('id', $id)->with('Fauna')->with('Flora')->with('User')->get();
    }

   /* public function scopeSpecificReport($query, $val)
    {
    	return $query->where('id', '=', $val)->get();
    }*/

    public function scopeMyReport($query, $val)
    {
    	return $query->where('user_id', '=', $val)->latest()->get();
    }

    public function scopeSpecificSpecieReport($query, $val)
    {
    	return $query->where('info_id', '=', $val)->get();
    } 

    public function user()
    {

        return $this->belongsTo(User::class);
    }

    public function fauna()
    {

        return $this->belongsTo(Fauna::class);
    }

    public function flora()
    {

        return $this->belongsTo(Flora::class);
    }

    
}

<?php

namespace App;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{

	protected $fillable = ['name', 'surname', 'username', 'email', 'password'];


    public function report()
    {
		 return $this->hasMany(Report::class);
    }

    public function publish(Report $report)
    {
		 $this->report()->save($report);
    }

    public static function getUser($email)
    {
        return static::where('email', $email)->get();
    }

}

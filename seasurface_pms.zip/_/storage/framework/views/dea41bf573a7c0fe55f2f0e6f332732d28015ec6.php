<!doctype html>

<html>
  <head>
   
    <title></title>   
   
  </head>
   
    <body>
     
     <div class="flex-center position-ref full-height">

          <?php if(auth()->guard()->check()): ?>
          
            <a href="/create"> Create report </a>
              
          <?php else: ?>
          
            <a href="/login"> Login to create a report</a>

          <?php endif; ?> 

      </div>
       
	<?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li>
      <a href="/reports/<?php echo e($report->id); ?>">
        <li> Report number: <?php echo e($report->id); ?> </li>
      </a> 
      	<li><?php echo e($report->description); ?></li>
      	<li><?php echo e($report->user->name); ?> "<?php echo e($report->user->username); ?>" <?php echo e($report->user->surname); ?> </li>
        
        <?php
        if (!isset($report->fauna->name)) {
          ?> <li><?php echo e($report->flora->name); ?></li> <?php 
        } 
        else {
          ?> <li><?php echo e($report->fauna->name); ?></li> <?php
        } 
        ?>
      	<li><?php echo e($report->picture); ?></li>
     
     </li>
     <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </body>

</html>


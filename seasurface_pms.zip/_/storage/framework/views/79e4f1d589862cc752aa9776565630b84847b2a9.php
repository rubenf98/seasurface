<!doctype html>

<html>
  <head>
   
    <title></title>   
   
  </head>
   
    <body>
      	<h1><?php echo e($faunas->name); ?> </h1>
      	<h1><?php echo e($faunas->description); ?></h1>
      	<h1><?php echo e($faunas->habitat); ?></h1>
        <h1><?php echo e($faunas->food); ?></h1>
        
        <?php
        if (!isset($faunas->picture)) {
          ?> <h1><?php echo e($faunas->picture); ?></h1> <?php 
        } ?>
        
        <?php
        if (!isset($faunas->lifespan)) {
          ?> <h1><?php echo e($faunas->lifespan); ?></h1> <?php 
        }?>
    </body>

</html>
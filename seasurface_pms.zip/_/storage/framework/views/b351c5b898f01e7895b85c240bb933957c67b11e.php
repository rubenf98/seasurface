<!doctype html>

<html>
  <head>
   
    <title></title>   
   
  </head>
   
    <body>
     
         
    <?php $__currentLoopData = $faunas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fauna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li>
      <a href="/info/fauna/<?php echo e($fauna->id); ?>">
        <li> Animal: <?php echo e($fauna->name); ?> </li>
      </a> 
        <li><?php echo e($fauna->description); ?></li>
        <li><?php echo e($fauna->habitat); ?></li>
        <li><?php echo e($fauna->food); ?></li>
        
        <?php
        if (!isset($fauna->picture)) {
          ?> <li><?php echo e($fauna->picture); ?></li> <?php 
        } ?>
        
        <?php
        if (!isset($fauna->lifespan)) {
          ?> <li><?php echo e($fauna->lifespan); ?></li> <?php 
        }?>
        <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </body>

</html>


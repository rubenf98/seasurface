<!doctype html>

<html>
  <head>
   
    <title></title>   
   
  </head>
   
    <body>
     
         
	<?php $__currentLoopData = $floras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li>
      <a href="/info/flora/<?php echo e($flora->id); ?>">
        <li> Flora: <?php echo e($flora->name); ?> </li>
      </a> 
        <li><?php echo e($flora->description); ?></li>
        <li><?php echo e($flora->habitat); ?></li>
        
        <?php
        if (!isset($flora->picture)) {
          ?> <li><?php echo e($flora->picture); ?></li> <?php 
        } ?>
     <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </body>

</html>


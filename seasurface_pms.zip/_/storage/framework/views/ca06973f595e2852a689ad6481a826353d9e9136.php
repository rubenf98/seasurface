<!doctype html>

<html>
  <head>
   
    <title></title>   
   
  </head>
   
    <body>
        <h1><?php echo e($floras->name); ?> </h1>
        <h1><?php echo e($floras->description); ?></h1>
        <h1><?php echo e($floras->habitat); ?></h1>
        
        <?php
        if (!isset($floras->picture)) {
          ?> <h1><?php echo e($floras->picture); ?></h1> <?php 
        } ?>
        
    </body>

</html>
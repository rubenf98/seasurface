<!doctype html>

<html>
  <head>
   
    <title></title>   
   
  </head>
   
    <body>
     
    	<div style="width: 1300px; height: 600px;">
			<?php echo Mapper::render(); ?>

		</div>
        
    </body>

</html>
<!doctype html>

<html>
  <head>
   
    <title></title>   
   
  </head>
   
    <body>
     
      <h1> create you report </h1>
      <hr>

      	<form method="POST" action="/report">
      		<?php echo e(csrf_field()); ?>


			      <div class="form-group">
			    <label for="specie" class="col-sm-2 control-label">Specie</label>
			    <div class="col-sm-10">
			      <input type="specie" class="form-control" id="specie" name="info_id" required>
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="latitude" class="col-sm-2 control-label">Latitude</label>
			    <div class="col-sm-10">
			      <input type="latitude" class="form-control" id="latitude" name="latitude" required>
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="longitude" class="col-sm-2 control-label">Longitude</label>
			    <div class="col-sm-10">
			      <input type="longitude" class="form-control" id="longitude" name="longitude" required>
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="description">Description</label>
			    <div>
			     	<textarea class="form-control" id="description" name="description"></textarea>
			 	</div>
			  </div>


			  <div class="form-group">
			    <label for="picture">Picture</label>
			    <input type="file" id="picture" name="picture">
			  </div>

			  <h1> </h1>
			  <h1> </h1>
			  <button type="submit" class="btn btn-primary">Submit</button>
		
			<?php if(count($errors)): ?>
				<div class="form-group">
					<div class="alert alert-danger"
						<u1>
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li><?php echo e($error); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</u1>
					</div>
				</div>
			<?php endif; ?>

	</form>



    </body>

</html>
<!doctype html>

<html>
  <head>
   
    <title></title>   
   
  </head>
   
    <body>

      <div class="flex-center position-ref full-height">

          <?php if(auth()->guard()->check()): ?>
          
            <a href="/#"> Hi <?php echo e(Auth::user()->username); ?> </a>
            <a href="/logout"> Logout </a>
              
          <?php else: ?>
          
            <a href="/login"> Login </a>
            <a href="/register"> Register </a>  

          <?php endif; ?> 

      </div>
            
      <hr>

      <h1> 
        <li> <a href="/map"> <?php echo e($mapa); ?> </a> </li>
        <li> <a href="/reports"> <?php echo e($reports); ?> </a> </li>
        <li> <a href="/info"> <?php echo e($info); ?> </a> </li>
      </h1>


    </body>

</html>

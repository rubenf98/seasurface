<!doctype html>

<html>
  <head>
   
    <title></title>   
   
  </head>
   
    <body>
      	<h1><?php echo e($reports->description); ?> </h1>
      	<h1><?php echo e($reports->user->name); ?> "<?php echo e($reports->user->username); ?>" <?php echo e($reports->user->surname); ?> </h1>
      	<?php
        if (!isset($reports->fauna->name)) {
          ?> <h1><?php echo e($reports->flora->name); ?></h1> <?php 
        } 
        else {
          ?> <h1><?php echo e($reports->fauna->name); ?></h1> <?php
        } 
        ?>
      	<h1><?php echo e($reports->latitude); ?></h1>
      	<h1><?php echo e($reports->longitude); ?></h1>
      	<h1><?php echo e($reports->picture); ?></h1>
        <h1><?php echo e($reports->created_at); ?></h1>
    </body>

</html>
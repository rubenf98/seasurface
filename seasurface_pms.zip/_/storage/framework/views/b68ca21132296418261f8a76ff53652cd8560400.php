<!doctype html>

<html>
  <head>
   
    <title></title>   
   
  </head>
   
    <body>
     
      <h1> create you report </h1>
      <hr>

      	<form method="POST" action="/report">
 
			<?php echo csrf_field(); ?>
		    <br><input checked="checked" name="type" value="fauna" type="radio" />fauna
			<input name="type" value="flora" type="radio" />flora</br>
			<br>

		    <div class="form-group">
		    	<label for="fauna" class="col-sm-2 control-label">Fauna</label>
		    	<div class="col-sm-10">
		      		<input type="fauna" class="form-control" id="fauna" name="fauna">
		    	</div>
		  	</div>

		  	<div class="form-group">
		    	<label for="flora" class="col-sm-2 control-label">Flora</label>
		    	<div class="col-sm-10">
		      		<input type="flora" class="form-control" id="flora" name="flora">
		    	</div>
		  	</div>

		  	<div class="form-group">
		    	<label for="latitude" class="col-sm-2 control-label">Latitude</label>
		    	<div class="col-sm-10">
		      		<input type="latitude" class="form-control" id="latitude" name="latitude" required>
		    	</div>
		  	</div>

			<div class="form-group">
				<label for="longitude" class="col-sm-2 control-label">Longitude</label>
			    <div class="col-sm-10">
			      <input type="longitude" class="form-control" id="longitude" name="longitude" required>
			    </div>
			</div>

		  	<div class="form-group">
			    <label for="description">Description</label>
			    <div>
			     	<textarea class="form-control" id="description" name="description"></textarea>
			 	</div>
		  	</div>


		  	<div class="form-group">
			    <label for="picture">Picture</label>
			    <input type="file" id="picture" name="picture">
		  	</div>

		  	<h1> </h1>
		  	<h1> </h1>
		  	<button type="submit" class="btn btn-primary">Submit</button>
		
			<?php if(count($errors)): ?>
				<div class="form-group">
					<div class="alert alert-danger"
						<u1>
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li><?php echo e($error); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</u1>
					</div>
				</div>
			<?php endif; ?>

	</form>



    </body>

</html>